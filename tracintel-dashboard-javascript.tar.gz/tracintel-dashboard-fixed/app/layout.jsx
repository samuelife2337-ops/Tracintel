import './globals.css'
import { Urbanist } from 'next/font/google'
import { BRANDING } from '../config/branding'

const urbanist = Urbanist({ 
  subsets: ['latin'],
  variable: '--font-urbanist',
  weight: ['300', '400', '500', '600', '700', '800'],
})

export const metadata = {
  title: `${BRANDING.name} - ${BRANDING.tagline}`,
  description: 'Monitor and improve your brand\'s visibility across AI platforms',
  icons: {
    icon: BRANDING.favicon,
  },
}

export default function RootLayout({ children }) {
  return (
    <html lang="en" className={urbanist.variable}>
      <body className="font-sans antialiased">{children}</body>
    </html>
  )
}
