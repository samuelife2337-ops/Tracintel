'use client'

import { useState, useEffect } from 'react'
import { BarChart3, TrendingUp, Package, AlertCircle, RefreshCw, Download } from 'lucide-react'
import { BRANDING, API } from '../config/branding'
import ScoreGauge from '../components/ScoreGauge'
import ProductList from '../components/ProductList'
import TrendChart from '../components/TrendChart'
import RecommendationsList from '../components/RecommendationsList'

export default function Dashboard() {
  const [loading, setLoading] = useState(false)
  const [data, setData] = useState(null)
  const [error, setError] = useState(null)
  const [shopUrl, setShopUrl] = useState('')

  // Fetch dashboard data
  const fetchDashboard = async () => {
    if (!shopUrl) return
    
    setLoading(true)
    setError(null)

    try {
      const response = await fetch(`${API.n8n}/webhook/scan/products`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          shop: shopUrl,
          limit: 10,
        }),
      })

      if (!response.ok) throw new Error('Failed to fetch data')

      const result = await response.json()
      setData(result)
    } catch (err) {
      setError(err.message)
    } finally {
      setLoading(false)
    }
  }

  const averageScore = data?.summary?.averageVisibilityScore || 0
  const totalProducts = data?.summary?.totalProductsScanned || 0
  const statusBreakdown = data?.summary?.statusBreakdown || {}

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100">
      {/* Header */}
      <header className="bg-white border-b border-slate-200 sticky top-0 z-50 backdrop-blur-sm bg-white/90">
        <div className="max-w-7xl mx-auto px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <img src="/logo.png" alt="Tracintel" className="h-8" />
              <span className="text-sm text-slate-500">{BRANDING.tagline}</span>
            </div>
            <div className="flex items-center space-x-4">
              <button className="p-2 hover:bg-slate-100 rounded-lg transition-colors">
                <RefreshCw className="w-5 h-5 text-slate-600" />
              </button>
              <button className="px-4 py-2 bg-black text-white rounded-lg hover:bg-gray-900 transition-colors flex items-center space-x-2">
                <Download className="w-4 h-4" />
                <span>Export</span>
              </button>
            </div>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-6 py-8">
        {/* Scan Input */}
        {!data && (
          <div className="mb-8 animate-slide-up">
            <div className="bg-white rounded-2xl shadow-lg p-8 border border-slate-200">
              <h2 className="text-2xl font-display font-bold mb-4 text-slate-900">
                Start Your AI Visibility Scan
              </h2>
              <p className="text-slate-600 mb-6">
                Enter your Shopify store URL to analyze how AI models see your products
              </p>
              <div className="flex space-x-4">
                <input
                  type="text"
                  placeholder="your-store.myshopify.com"
                  value={shopUrl}
                  onChange={(e) => setShopUrl(e.target.value)}
                  className="flex-1 px-4 py-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-brand-primary focus:border-transparent outline-none"
                />
                <button
                  onClick={fetchDashboard}
                  disabled={loading || !shopUrl}
                  className="px-8 py-3 bg-black text-white rounded-lg hover:bg-gray-900 hover:shadow-lg transition-all disabled:opacity-50 disabled:cursor-not-allowed font-semibold"
                >
                  {loading ? 'Scanning...' : 'Scan Store'}
                </button>
              </div>
              {error && (
                <div className="mt-4 p-4 bg-red-50 border border-red-200 rounded-lg flex items-start space-x-3">
                  <AlertCircle className="w-5 h-5 text-red-600 flex-shrink-0 mt-0.5" />
                  <div className="text-red-800">{error}</div>
                </div>
              )}
            </div>
          </div>
        )}

        {/* Dashboard Content */}
        {data && (
          <div className="space-y-6 animate-fade-in">
            {/* Stats Overview */}
            <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
              {/* Overall Score */}
              <div className="md:col-span-2 bg-white rounded-2xl shadow-lg p-8 border border-slate-200">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="text-lg font-semibold text-slate-700">AI Visibility Score</h3>
                  <TrendingUp className="w-5 h-5 text-brand-accent" />
                </div>
                <ScoreGauge score={averageScore} size="large" />
                <p className="text-center text-slate-600 mt-4">
                  Average across {totalProducts} products
                </p>
              </div>

              {/* Quick Stats */}
              <div className="bg-white rounded-2xl shadow-lg p-6 border border-slate-200">
                <div className="flex items-center space-x-3 mb-4">
                  <div className="p-3 bg-green-100 rounded-lg">
                    <Package className="w-6 h-6 text-green-600" />
                  </div>
                  <div>
                    <div className="text-2xl font-bold text-slate-900">{statusBreakdown.excellent || 0}</div>
                    <div className="text-sm text-slate-600">Excellent</div>
                  </div>
                </div>
                <div className="h-2 bg-slate-100 rounded-full overflow-hidden">
                  <div 
                    className="h-full bg-green-500 rounded-full transition-all"
                    style={{ width: `${(statusBreakdown.excellent / totalProducts) * 100}%` }}
                  />
                </div>
              </div>

              <div className="bg-white rounded-2xl shadow-lg p-6 border border-slate-200">
                <div className="flex items-center space-x-3 mb-4">
                  <div className="p-3 bg-red-100 rounded-lg">
                    <AlertCircle className="w-6 h-6 text-red-600" />
                  </div>
                  <div>
                    <div className="text-2xl font-bold text-slate-900">{statusBreakdown.poor || 0}</div>
                    <div className="text-sm text-slate-600">Needs Work</div>
                  </div>
                </div>
                <div className="h-2 bg-slate-100 rounded-full overflow-hidden">
                  <div 
                    className="h-full bg-red-500 rounded-full transition-all"
                    style={{ width: `${(statusBreakdown.poor / totalProducts) * 100}%` }}
                  />
                </div>
              </div>
            </div>

            {/* Charts & Recommendations */}
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              {/* Trend Chart */}
              <div className="lg:col-span-2 bg-white rounded-2xl shadow-lg p-6 border border-slate-200">
                <h3 className="text-lg font-semibold text-slate-700 mb-4 flex items-center">
                  <BarChart3 className="w-5 h-5 mr-2 text-brand-primary" />
                  Score Distribution
                </h3>
                <TrendChart data={data.products} />
              </div>

              {/* Top Recommendations */}
              <div className="bg-white rounded-2xl shadow-lg p-6 border border-slate-200">
                <h3 className="text-lg font-semibold text-slate-700 mb-4">Top Actions</h3>
                <RecommendationsList products={data.products} />
              </div>
            </div>

            {/* Product List */}
            <div className="bg-white rounded-2xl shadow-lg border border-slate-200 overflow-hidden">
              <div className="p-6 border-b border-slate-200">
                <h3 className="text-lg font-semibold text-slate-700">Product Visibility Report</h3>
              </div>
              <ProductList products={data.products} />
            </div>

            {/* Scan Again */}
            <div className="text-center">
              <button
                onClick={() => setData(null)}
                className="px-6 py-3 bg-slate-200 text-slate-700 rounded-lg hover:bg-slate-300 transition-colors font-semibold"
              >
                Scan Another Store
              </button>
            </div>
          </div>
        )}

        {/* Loading State */}
        {loading && (
          <div className="flex flex-col items-center justify-center py-20">
            <div className="w-16 h-16 border-4 border-brand-primary border-t-transparent rounded-full animate-spin mb-4"></div>
            <p className="text-slate-600 font-semibold">Scanning your products...</p>
            <p className="text-slate-500 text-sm mt-2">Analyzing with ChatGPT, Claude, and Gemini</p>
          </div>
        )}
      </main>

      {/* Footer */}
      <footer className="bg-white border-t border-slate-200 mt-20">
        <div className="max-w-7xl mx-auto px-6 py-8 text-center text-slate-600 text-sm">
          <p>© 2026 {BRANDING.name}. All rights reserved.</p>
        </div>
      </footer>
    </div>
  )
}
