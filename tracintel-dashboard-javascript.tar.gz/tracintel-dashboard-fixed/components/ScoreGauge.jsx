'use client'

export default function ScoreGauge({ score, size = 'medium' }) {
  const getStatus = (score) => {
    if (score >= 80) return { label: 'Excellent', color: 'text-green-600', bg: 'bg-green-500' }
    if (score >= 60) return { label: 'Good', color: 'text-yellow-600', bg: 'bg-yellow-500' }
    if (score >= 40) return { label: 'Fair', color: 'text-orange-600', bg: 'bg-orange-500' }
    return { label: 'Poor', color: 'text-red-600', bg: 'bg-red-500' }
  }

  const status = getStatus(score)
  const radius = size === 'large' ? 80 : size === 'medium' ? 60 : 40
  const circumference = 2 * Math.PI * radius
  const offset = circumference - (score / 100) * circumference

  return (
    <div className="flex flex-col items-center">
      {/* Circular Progress */}
      <div className="relative">
        <svg className="transform -rotate-90" width={radius * 2.5} height={radius * 2.5}>
          {/* Background circle */}
          <circle
            cx={radius * 1.25}
            cy={radius * 1.25}
            r={radius}
            stroke="currentColor"
            strokeWidth="12"
            fill="none"
            className="text-slate-200"
          />
          {/* Progress circle */}
          <circle
            cx={radius * 1.25}
            cy={radius * 1.25}
            r={radius}
            stroke="currentColor"
            strokeWidth="12"
            fill="none"
            strokeDasharray={circumference}
            strokeDashoffset={offset}
            strokeLinecap="round"
            className={status.bg.replace('bg-', 'text-')}
            style={{ transition: 'stroke-dashoffset 1s ease-in-out' }}
          />
        </svg>
        
        {/* Score Display */}
        <div className="absolute inset-0 flex flex-col items-center justify-center">
          <div className={`text-5xl font-bold ${status.color}`}>
            {score}
          </div>
          <div className="text-slate-500 text-sm font-semibold mt-1">
            / 100
          </div>
        </div>
      </div>

      {/* Status Label */}
      <div className={`mt-4 px-4 py-2 rounded-full text-sm font-semibold ${status.bg} bg-opacity-10 ${status.color}`}>
        {status.label}
      </div>
    </div>
  )
}
