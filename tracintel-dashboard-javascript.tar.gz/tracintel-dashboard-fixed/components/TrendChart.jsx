'use client'

import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Cell } from 'recharts'

export default function TrendChart({ data }) {
  if (!data || data.length === 0) {
    return <div className="text-center text-slate-500 py-8">No data available</div>
  }

  // Prepare chart data
  const chartData = data.map((product, index) => ({
    name: product.title?.substring(0, 20) + '...' || `Product ${index + 1}`,
    score: product.score || 0,
    status: product.status,
  }))

  const getBarColor = (status) => {
    const colors = {
      'Excellent': '#10b981',
      'Good': '#f59e0b',
      'Fair': '#f97316',
      'Poor': '#ef4444',
    }
    return colors[status] || '#64748b'
  }

  return (
    <ResponsiveContainer width="100%" height={300}>
      <BarChart data={chartData} margin={{ top: 10, right: 10, left: 0, bottom: 60 }}>
        <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
        <XAxis 
          dataKey="name" 
          angle={-45}
          textAnchor="end"
          height={80}
          tick={{ fontSize: 12, fill: '#64748b' }}
        />
        <YAxis 
          domain={[0, 100]}
          tick={{ fontSize: 12, fill: '#64748b' }}
        />
        <Tooltip 
          contentStyle={{
            backgroundColor: '#ffffff',
            border: '1px solid #e2e8f0',
            borderRadius: '8px',
            boxShadow: '0 4px 6px -1px rgba(0, 0, 0, 0.1)',
          }}
          labelStyle={{ fontWeight: 600, color: '#1e293b' }}
        />
        <Bar dataKey="score" radius={[8, 8, 0, 0]}>
          {chartData.map((entry, index) => (
            <Cell key={`cell-${index}`} fill={getBarColor(entry.status)} />
          ))}
        </Bar>
      </BarChart>
    </ResponsiveContainer>
  )
}
