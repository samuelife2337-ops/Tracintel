'use client'

import { ExternalLink, TrendingUp, TrendingDown } from 'lucide-react'

export default function ProductList({ products }) {
  if (!products || products.length === 0) {
    return (
      <div className="p-8 text-center text-slate-500">
        No products found
      </div>
    )
  }

  const getStatusColor = (status) => {
    const colors = {
      'Excellent': 'bg-green-100 text-green-800 border-green-200',
      'Good': 'bg-yellow-100 text-yellow-800 border-yellow-200',
      'Fair': 'bg-orange-100 text-orange-800 border-orange-200',
      'Poor': 'bg-red-100 text-red-800 border-red-200',
    }
    return colors[status] || 'bg-slate-100 text-slate-800 border-slate-200'
  }

  return (
    <div className="overflow-x-auto">
      <table className="w-full">
        <thead className="bg-slate-50 border-b border-slate-200">
          <tr>
            <th className="px-6 py-4 text-left text-xs font-semibold text-slate-600 uppercase tracking-wider">
              Product
            </th>
            <th className="px-6 py-4 text-center text-xs font-semibold text-slate-600 uppercase tracking-wider">
              Score
            </th>
            <th className="px-6 py-4 text-center text-xs font-semibold text-slate-600 uppercase tracking-wider">
              Status
            </th>
            <th className="px-6 py-4 text-center text-xs font-semibold text-slate-600 uppercase tracking-wider">
              ChatGPT
            </th>
            <th className="px-6 py-4 text-center text-xs font-semibold text-slate-600 uppercase tracking-wider">
              Claude
            </th>
            <th className="px-6 py-4 text-center text-xs font-semibold text-slate-600 uppercase tracking-wider">
              Gemini
            </th>
            <th className="px-6 py-4 text-center text-xs font-semibold text-slate-600 uppercase tracking-wider">
              Actions
            </th>
          </tr>
        </thead>
        <tbody className="divide-y divide-slate-200">
          {products.map((product, index) => (
            <tr 
              key={product.id || index} 
              className="hover:bg-slate-50 transition-colors"
            >
              <td className="px-6 py-4">
                <div className="flex items-center space-x-3">
                  <div className="flex-shrink-0 w-12 h-12 bg-slate-200 rounded-lg overflow-hidden">
                    {product.imageUrl && (
                      <img 
                        src={product.imageUrl} 
                        alt={product.title}
                        className="w-full h-full object-cover"
                      />
                    )}
                  </div>
                  <div>
                    <div className="font-semibold text-slate-900 max-w-xs truncate">
                      {product.title}
                    </div>
                    <div className="text-sm text-slate-500">
                      ID: {product.id}
                    </div>
                  </div>
                </div>
              </td>
              
              <td className="px-6 py-4 text-center">
                <div className="flex items-center justify-center">
                  <div className="text-2xl font-bold text-slate-900">
                    {product.score}
                  </div>
                  <div className="ml-2">
                    {product.score >= 70 ? (
                      <TrendingUp className="w-4 h-4 text-green-600" />
                    ) : (
                      <TrendingDown className="w-4 h-4 text-red-600" />
                    )}
                  </div>
                </div>
              </td>
              
              <td className="px-6 py-4 text-center">
                <span className={`inline-flex items-center px-3 py-1 rounded-full text-xs font-semibold border ${getStatusColor(product.status)}`}>
                  {product.statusEmoji} {product.status}
                </span>
              </td>
              
              <td className="px-6 py-4 text-center">
                <div className="text-sm font-semibold text-slate-700">
                  {product.chatgptScore || '-'}
                </div>
              </td>
              
              <td className="px-6 py-4 text-center">
                <div className="text-sm font-semibold text-slate-700">
                  {product.claudeScore || '-'}
                </div>
              </td>
              
              <td className="px-6 py-4 text-center">
                <div className="text-sm font-semibold text-slate-700">
                  {product.geminiScore || '-'}
                </div>
              </td>
              
              <td className="px-6 py-4 text-center">
                {product.url && (
                  <a
                    href={product.url}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center text-brand-primary hover:text-brand-secondary transition-colors"
                  >
                    <ExternalLink className="w-4 h-4" />
                  </a>
                )}
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  )
}
