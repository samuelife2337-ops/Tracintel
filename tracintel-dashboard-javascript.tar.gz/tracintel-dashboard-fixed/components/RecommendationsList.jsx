'use client'

import { AlertCircle, CheckCircle, ArrowRight } from 'lucide-react'

export default function RecommendationsList({ products }) {
  if (!products || products.length === 0) {
    return null
  }

  // Find products that need attention
  const poorProducts = products
    .filter(p => p.score < 60)
    .sort((a, b) => a.score - b.score)
    .slice(0, 5)

  const recommendations = poorProducts.map(product => ({
    product: product.title,
    score: product.score,
    action: getRecommendation(product.score),
    priority: product.score < 40 ? 'high' : 'medium',
  }))

  function getRecommendation(score) {
    if (score < 40) {
      return 'Add detailed product descriptions'
    } else if (score < 60) {
      return 'Improve product SEO content'
    }
    return 'Optimize product information'
  }

  if (recommendations.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center py-8 text-center">
        <CheckCircle className="w-12 h-12 text-green-500 mb-3" />
        <p className="font-semibold text-slate-700">All Products Looking Good!</p>
        <p className="text-sm text-slate-500 mt-1">No critical actions needed</p>
      </div>
    )
  }

  return (
    <div className="space-y-3">
      {recommendations.map((rec, index) => (
        <div 
          key={index}
          className="p-4 bg-slate-50 rounded-lg border border-slate-200 hover:border-brand-primary transition-colors group cursor-pointer"
        >
          <div className="flex items-start space-x-3">
            <div className={`mt-0.5 ${
              rec.priority === 'high' 
                ? 'text-red-600' 
                : 'text-yellow-600'
            }`}>
              <AlertCircle className="w-5 h-5" />
            </div>
            <div className="flex-1 min-w-0">
              <div className="font-semibold text-slate-900 text-sm truncate">
                {rec.product}
              </div>
              <div className="text-xs text-slate-600 mt-1">
                Score: {rec.score}/100
              </div>
              <div className="text-sm text-slate-700 mt-2">
                {rec.action}
              </div>
            </div>
            <ArrowRight className="w-4 h-4 text-slate-400 group-hover:text-brand-primary transition-colors flex-shrink-0" />
          </div>
        </div>
      ))}
    </div>
  )
}
