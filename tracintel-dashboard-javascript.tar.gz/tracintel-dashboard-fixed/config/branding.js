// TRACINTEL BRANDING CONFIGURATION
// ================================
// EDIT THIS FILE TO CUSTOMIZE BRANDING

export const BRANDING = {
  // Company Info
  name: 'Tracintel',
  tagline: 'AI Visibility & Control Platform',
  
  // Logo & Images
  logo: '/logo.png',              // Tracintel full logo
  logoText: '/logo-text.png',     // Text-only logo
  logoIcon: '/favicon.png',       // Icon only
  favicon: '/favicon.png',
  
  // Brand Colors (HEX codes) - Tracintel Black & Modern
  colors: {
    primary: '#000000',     // Black (main brand)
    secondary: '#1a1a1a',   // Dark gray
    accent: '#3b82f6',      // Modern blue accent
    
    // Status colors (for scores)
    excellent: '#10b981',   // Green
    good: '#f59e0b',        // Yellow
    fair: '#f97316',        // Orange
    poor: '#ef4444',        // Red
  },
  
  // Typography
  fonts: {
    display: 'Cal Sans, DM Sans, sans-serif',
    body: 'DM Sans, system-ui, sans-serif',
  },
  
  // Links
  website: 'https://tracintel.com',
  support: 'mailto:support@tracintel.com',
  docs: 'https://docs.tracintel.com',
  
  // Feature Flags
  features: {
    darkMode: true,
    notifications: true,
    charts: true,
    export: true,
  },
}

// API Configuration
export const API = {
  n8n: process.env.NEXT_PUBLIC_N8N_URL || 'https://n8n.srv1246553.hstgr.cloud',
  supabase: {
    url: process.env.NEXT_PUBLIC_SUPABASE_URL || '',
    anonKey: process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY || '',
  },
}

// Dashboard Settings
export const DASHBOARD = {
  defaultScanLimit: 10,
  refreshInterval: 30000, // 30 seconds
  maxProductsDisplay: 50,
}
