# Tracintel Dashboard

AI Visibility & Control Platform - Monitor how AI models see your products

---

## 🚀 Quick Start

### 1. Install Dependencies

```bash
npm install
# or
yarn install
```

### 2. Environment Variables

Create `.env.local` file:

```env
NEXT_PUBLIC_N8N_URL=https://n8n.srv1246553.hstgr.cloud
NEXT_PUBLIC_SUPABASE_URL=your_supabase_url
NEXT_PUBLIC_SUPABASE_ANON_KEY=your_supabase_anon_key
```

### 3. Run Development Server

```bash
npm run dev
```

Open [http://localhost:3000](http://localhost:3000)

---

## 🎨 Customize Branding

### Update Brand Colors & Info

Edit `config/branding.js`:

```javascript
export const BRANDING = {
  name: 'Tracintel',
  colors: {
    primary: '#2563eb',     // Change this
    secondary: '#7c3aed',   // Change this
    accent: '#10b981',      // Change this
  },
}
```

### Replace Logo

1. Add your logo to `/public/logo.svg`
2. Add favicon to `/public/favicon.ico`
3. Update paths in `config/branding.js`

### Change Colors in Tailwind

Edit `tailwind.config.js`:

```javascript
theme: {
  extend: {
    colors: {
      brand: {
        primary: '#YOUR_COLOR',
        secondary: '#YOUR_COLOR',
      }
    }
  }
}
```

---

## 📦 Build for Production

```bash
npm run build
npm start
```

---

## 🚀 Deploy to Vercel

### Method 1: GitHub (Recommended)

1. Push code to GitHub
2. Go to [vercel.com](https://vercel.com)
3. Import your repository
4. Add environment variables
5. Deploy!

### Method 2: Vercel CLI

```bash
npm install -g vercel
vercel --prod
```

### Add Environment Variables in Vercel

1. Go to Project → Settings → Environment Variables
2. Add:
   - `NEXT_PUBLIC_N8N_URL`
   - `NEXT_PUBLIC_SUPABASE_URL`
   - `NEXT_PUBLIC_SUPABASE_ANON_KEY`
3. Redeploy

---

## 🌐 Connect Custom Domain

### 1. In Vercel Dashboard

- Go to Project → Settings → Domains
- Add `tracintel.com`
- Add `www.tracintel.com`

### 2. Update DNS (Where you bought domain)

Add these records:

```
Type: A
Name: @
Value: 76.76.21.21

Type: CNAME
Name: www
Value: cname.vercel-dns.com
```

Wait 24 hours for DNS propagation.

---

## 📁 Project Structure

```
tracintel-dashboard/
├── app/
│   ├── page.tsx          # Main dashboard
│   ├── layout.tsx        # App layout
│   └── globals.css       # Global styles
├── components/
│   ├── ScoreGauge.tsx    # Score display
│   ├── ProductList.tsx   # Product table
│   ├── TrendChart.tsx    # Charts
│   └── RecommendationsList.tsx
├── config/
│   └── branding.js       # EDIT THIS FOR BRANDING
├── public/
│   ├── logo.svg          # REPLACE WITH YOUR LOGO
│   └── favicon.ico       # REPLACE WITH YOUR FAVICON
├── package.json
├── tailwind.config.js    # Tailwind configuration
└── next.config.js
```

---

## 🎯 Features

- ✅ Real-time AI visibility scoring
- ✅ Multi-platform analysis (ChatGPT, Claude, Gemini)
- ✅ Product-level insights
- ✅ Visual score gauges
- ✅ Trend charts
- ✅ Actionable recommendations
- ✅ Responsive design
- ✅ Easy branding customization

---

## 🔧 API Integration

### n8n Backend

Dashboard connects to your n8n workflows:

- **Scan Products**: `POST /webhook/scan/products`
- **Get History**: `GET /webhook/scan/history`

### Supabase Database

Stores scan results and historical data.

---

## 🎨 Customization Guide

### Change Primary Color

1. Edit `config/branding.js`:
   ```javascript
   colors: {
     primary: '#FF6B6B', // New color
   }
   ```

2. Edit `tailwind.config.js`:
   ```javascript
   brand: {
     primary: '#FF6B6B',
   }
   ```

3. Restart dev server

### Add Your Logo

1. Export your logo as SVG
2. Save to `/public/logo.svg`
3. Logo will appear automatically

### Change Fonts

1. Edit `app/layout.tsx`
2. Import new font from Google Fonts
3. Update `tailwind.config.js`

---

## 📊 Dashboard Features

### Overview Page
- Overall AI visibility score
- Product count and breakdown
- Status distribution
- Quick actions

### Product List
- All scanned products
- Individual scores
- AI platform breakdown
- Status indicators

### Charts
- Score distribution
- Trend analysis
- Comparison views

### Recommendations
- Actionable insights
- Prioritized by impact
- Product-specific tips

---

## 🐛 Troubleshooting

### Dashboard not loading?
- Check `.env.local` file exists
- Verify n8n URL is correct
- Check network tab for errors

### Scan not working?
- Verify Shopify store URL format
- Check n8n workflow is active
- Ensure API keys are configured

### Styling issues?
- Clear browser cache
- Rebuild: `npm run build`
- Check Tailwind config

---

## 📞 Support

- Website: https://tracintel.com
- Email: support@tracintel.com
- Docs: https://docs.tracintel.com

---

## 📝 License

© 2026 Tracintel. All rights reserved.
